package main.java.ui.client;

public class SurveyPanel {
}
