package main.java.ui.admin;

import main.java.context.ExamCreationContext;
import main.java.model.Exam;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class ExamEditPanel extends JPanel {
    private final JTextField subjectField = new JTextField();
    private final JSpinner durationSpinner = new JSpinner(new SpinnerNumberModel(60, 1, 300, 5));
    private final JSpinner startDateSpinner = new JSpinner(new SpinnerDateModel());
    private final JSpinner endDateSpinner = new JSpinner(new SpinnerDateModel());

    private final ExamCreationContext context;
    private final Runnable goPrev;
    private final Runnable goNext;

    public ExamEditPanel(ExamCreationContext context, Runnable goPrev, Runnable goNext) {
        this.context = context;
        this.goPrev = goPrev;
        this.goNext = goNext;

        initComponents();
        loadDataIfEditing();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JLabel title = new JLabel("시험 등록/수정", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(4, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        form.add(new JLabel("과목명"));
        form.add(subjectField);
        form.add(new JLabel("제한 시간(분)"));
        form.add(durationSpinner);
        form.add(new JLabel("시작일"));
        startDateSpinner.setEditor(new JSpinner.DateEditor(startDateSpinner, "yyyy-MM-dd HH:mm"));
        form.add(startDateSpinner);
        form.add(new JLabel("마감일"));
        endDateSpinner.setEditor(new JSpinner.DateEditor(endDateSpinner, "yyyy-MM-dd HH:mm"));
        form.add(endDateSpinner);
        add(form, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        JButton prevBtn = new JButton("이전");
        JButton nextBtn = new JButton("다음");

        prevBtn.addActionListener(e -> goPrev.run());
        nextBtn.addActionListener(e -> {
            if (!validateInput()) return;

            Exam exam = context.getExam();
            if (exam == null) exam = new Exam();
            exam.setSubject(subjectField.getText().trim());
            exam.setDurationMinutes((int) durationSpinner.getValue());
            exam.setStartDate(convertToLocalDateTime((Date) startDateSpinner.getValue()));
            exam.setEndDate(convertToLocalDateTime((Date) endDateSpinner.getValue()));
            context.setExam(exam);

            goNext.run();
        });

        btnPanel.add(prevBtn);
        btnPanel.add(nextBtn);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void loadDataIfEditing() {
        Exam exam = context.getExam();
        if (exam != null) {
            subjectField.setText(exam.getSubject());
            durationSpinner.setValue(exam.getDurationMinutes());
            startDateSpinner.setValue(java.sql.Timestamp.valueOf(exam.getStartDate()));
            endDateSpinner.setValue(java.sql.Timestamp.valueOf(exam.getEndDate()));
        }
    }

    private boolean validateInput() {
        String subject = subjectField.getText().trim();
        if (subject.isEmpty()) {
            JOptionPane.showMessageDialog(this, "과목명을 입력해주세요.");
            return false;
        }

        Date start = (Date) startDateSpinner.getValue();
        Date end = (Date) endDateSpinner.getValue();
        if (!end.after(new Date())) {
            JOptionPane.showMessageDialog(this, "마감일은 현재 시각보다 이후여야 합니다.");
            return false;
        }
        if (!end.after(start)) {
            JOptionPane.showMessageDialog(this, "마감일은 시작일보다 늦어야 합니다.");
            return false;
        }

        return true;
    }

    private LocalDateTime convertToLocalDateTime(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }
}
