package main.java.ui.admin;

import main.java.model.Exam;
import main.java.service.ExamService;
import main.java.service.ExamServiceImpl;
import main.java.service.ServiceException;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.function.Consumer;

public class ExamEditorPanel extends JPanel {
    private final ExamService examService = new ExamServiceImpl();
    private final JTextField subjectField = new JTextField();
    private final JSpinner durationSpinner = new JSpinner(new SpinnerNumberModel(60, 10, 180, 5));
    private final JSpinner startDateSpinner = new JSpinner(new SpinnerDateModel());
    private final JSpinner endDateSpinner = new JSpinner(new SpinnerDateModel());

    private final JButton backButton = new JButton("이전");
    private final JButton nextButton = new JButton("다음");

    private final Consumer<Exam> onNext;
    private final Runnable onBack;

    private Exam editingExam;

    public ExamEditorPanel(Exam exam, Consumer<Exam> onNext, Runnable onBack) {
        this.onNext = onNext;
        this.onBack = onBack;
        this.editingExam = exam;

        setLayout(new BorderLayout());
        JLabel header = new JLabel("시험 정보 입력");
        header.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        header.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(header, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        formPanel.add(new JLabel("과목명"));
        formPanel.add(subjectField);
        formPanel.add(new JLabel("제한시간(분)"));
        formPanel.add(durationSpinner);
        formPanel.add(new JLabel("시작일"));
        formPanel.add(startDateSpinner);
        formPanel.add(new JLabel("마감일"));
        formPanel.add(endDateSpinner);
        add(formPanel, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.add(backButton);
        btnPanel.add(nextButton);
        add(btnPanel, BorderLayout.SOUTH);

        backButton.addActionListener(e -> onBack.run());
        nextButton.addActionListener(e -> handleNext());

        ((JSpinner.DateEditor) startDateSpinner.getEditor()).getFormat().applyPattern("yyyy-MM-dd HH:mm");
        ((JSpinner.DateEditor) endDateSpinner.getEditor()).getFormat().applyPattern("yyyy-MM-dd HH:mm");

        // 기존 값 불러오기 (수정일 경우)
        if (editingExam != null) {
            subjectField.setText(editingExam.getSubject());
            durationSpinner.setValue(editingExam.getDurationMinutes());
            startDateSpinner.setValue(java.sql.Timestamp.valueOf(editingExam.getStartDate()));
            endDateSpinner.setValue(java.sql.Timestamp.valueOf(editingExam.getEndDate()));
        }
    }

    private void handleNext() {
        String subject = subjectField.getText().trim();
        int duration = (int) durationSpinner.getValue();
        LocalDateTime start = LocalDateTime.ofInstant(((java.util.Date) startDateSpinner.getValue()).toInstant(), java.time.ZoneId.systemDefault());
        LocalDateTime end = LocalDateTime.ofInstant(((java.util.Date) endDateSpinner.getValue()).toInstant(), java.time.ZoneId.systemDefault());

        if (subject.isEmpty()) {
            JOptionPane.showMessageDialog(this, "과목명을 입력해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (end.isBefore(LocalDateTime.now())) {
            JOptionPane.showMessageDialog(this, "시험 마감일은 현재 이후로 설정해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (end.isBefore(start)) {
            JOptionPane.showMessageDialog(this, "마감일은 시작일 이후로 설정해야 합니다.", "입력 오류", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (editingExam == null) {
            editingExam = new Exam();
        }

        editingExam.setSubject(subject);
        editingExam.setDurationMinutes(duration);
        editingExam.setStartDate(start);
        editingExam.setEndDate(end);

        onNext.accept(editingExam);
    }
}