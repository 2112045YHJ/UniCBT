package main.java.ui.admin;

public class ExamProgressPanel {
}
