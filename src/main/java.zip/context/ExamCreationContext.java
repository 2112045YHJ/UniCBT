package main.java.context;

import main.java.model.Exam;
import java.util.ArrayList;
import java.util.List;

public class ExamCreationContext {
    private Exam exam;
    // 이후 문제, 응시 대상 정보도 여기에 추가 가능

    public Exam getExam() {
        return exam;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }

    public void clear() {
        this.exam = null;
    }
}
