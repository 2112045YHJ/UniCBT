package main.java.model;

import java.time.LocalDateTime;

public class ExamResult {
    private int resultId;
    private int examId;
    private int userId;
    private int score;
    private LocalDateTime completedAt;

    public ExamResult() {
    }
    public ExamResult(int userId, int examId, int score) {
        this.userId = userId;
        this.examId = examId;
        this.score = score;
    }

    public int getResultId() {
        return resultId;
    }

    public void setResultId(int resultId) {
        this.resultId = resultId;
    }

    public int getExamId() {
        return examId;
    }

    public void setExamId(int examId) {
        this.examId = examId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }
}
